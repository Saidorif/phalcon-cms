-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 09, 2019 at 09:52 AM
-- Server version: 5.7.25
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uzbinvest`
--

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE `newsletter` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`id`, `email`) VALUES
(3, 'admin@nextmall.uz'),
(4, 'sayyid2112@gmail.com'),
(7, 'Jahongir838@mail.ru'),
(8, 'sobirovtoxir@mail.ru'),
(9, 'apamela91@bk.ru');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter_list`
--

CREATE TABLE `newsletter_list` (
  `id` int(11) NOT NULL,
  `news_id` int(11) NOT NULL,
  `language` varchar(255) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `newsletter_list`
--

INSERT INTO `newsletter_list` (`id`, `news_id`, `language`, `date`) VALUES
(1, 9, 'oz', '2017-12-11 13:55:46'),
(2, 8, 'oz', '2017-12-11 14:02:47'),
(3, 1, 'oz', '2017-12-11 16:00:15'),
(4, 2, 'oz', '2017-12-11 16:01:25'),
(5, 3, 'oz', '2017-12-11 16:12:01'),
(6, 6, 'oz', '2017-12-11 16:13:43'),
(7, 10, 'oz', '2017-12-11 16:35:00'),
(8, 11, 'oz', '2017-12-13 15:26:39'),
(9, 14, 'oz', '2017-12-13 15:27:34');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter_settings`
--

CREATE TABLE `newsletter_settings` (
  `id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `from_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `newsletter_settings`
--

INSERT INTO `newsletter_settings` (`id`, `category`, `email`, `from_name`) VALUES
(1, 2, 'sayyid2112@gmail.com', '«Узбекинвест» ЭИМСК');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletter_list`
--
ALTER TABLE `newsletter_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletter_settings`
--
ALTER TABLE `newsletter_settings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `newsletter_list`
--
ALTER TABLE `newsletter_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `newsletter_settings`
--
ALTER TABLE `newsletter_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
