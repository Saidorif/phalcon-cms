<?php

namespace Poll\Model\Translate;

use Application\Mvc\Model\Translate;

class PollTranslate extends Translate
{

    public function getSource()
    {
        return "poll_translate";
    }

}