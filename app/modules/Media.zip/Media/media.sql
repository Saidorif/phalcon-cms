-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 12 2018 г., 13:08
-- Версия сервера: 5.5.53
-- Версия PHP: 5.6.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `uzbekinvest`
--

-- --------------------------------------------------------

--
-- Структура таблицы `media`
--

CREATE TABLE `media` (
  `id` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `anons` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `kod_video` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `media`
--

INSERT INTO `media` (`id`, `slug`, `category_id`, `anons`, `video`, `kod_video`) VALUES
(1, 'foto01', 2, 'files/original/media/1.jpg', 'uploads/video-gallery/1.mp4', ''),
(3, 'foto', 1, 'files/original/media/3.jpg', NULL, '');

-- --------------------------------------------------------

--
-- Структура таблицы `media_category`
--

CREATE TABLE `media_category` (
  `id` int(11) NOT NULL,
  `sort` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `media_category`
--

INSERT INTO `media_category` (`id`, `sort`) VALUES
(1, 1),
(2, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `media_category_translate`
--

CREATE TABLE `media_category_translate` (
  `id` int(11) NOT NULL,
  `foreign_id` int(11) NOT NULL,
  `lang` varchar(255) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `media_category_translate`
--

INSERT INTO `media_category_translate` (`id`, `foreign_id`, `lang`, `key`, `value`) VALUES
(1, 1, 'ru', 'title', 'Фотогалерея'),
(2, 2, 'ru', 'title', 'Видеоматериалы'),
(3, 3, 'ru', 'title', 'foto'),
(4, 4, 'uz', 'title', 'Foto'),
(5, 1, 'uz', 'title', 'Foto'),
(6, 2, 'uz', 'title', 'Video'),
(7, 1, 'oz', 'title', 'Фотогалерея'),
(8, 2, 'oz', 'title', 'Видеогалерея ');

-- --------------------------------------------------------

--
-- Структура таблицы `media_gallery`
--

CREATE TABLE `media_gallery` (
  `id` int(11) NOT NULL,
  `media_id` int(11) NOT NULL,
  `file` varchar(255) NOT NULL,
  `file_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `media_gallery`
--

INSERT INTO `media_gallery` (`id`, `media_id`, `file`, `file_id`) VALUES
(13, 3, 'files/original/media_gallery/8011a5d2e1418976dae9968b84d435c3.jpg', '8011a5d2e1418976dae9968b84d435c3'),
(14, 3, 'files/original/media_gallery/35423e4b4cef65576766b522c3b5f1fa.jpg', '35423e4b4cef65576766b522c3b5f1fa'),
(15, 3, 'files/original/media_gallery/593a4adebd44f3fe2bbc467db82fb0e3.jpg', '593a4adebd44f3fe2bbc467db82fb0e3'),
(16, 3, 'files/original/media_gallery/75ea575d2a31fb39f578b8b90f9c3803.jpg', '75ea575d2a31fb39f578b8b90f9c3803'),
(17, 3, 'files/original/media_gallery/d46933ba6b45fcf427f07c90863f6bf6.jpg', 'd46933ba6b45fcf427f07c90863f6bf6'),
(18, 3, 'files/original/media_gallery/f8e321ecc15d32a257d8d98248778817.jpg', 'f8e321ecc15d32a257d8d98248778817'),
(20, 3, 'files/original/media_gallery/8d7aeebaf04a434e87917367b39edc3e.jpg', '8d7aeebaf04a434e87917367b39edc3e'),
(21, 3, 'files/original/media_gallery/5474c7479a54f3e99a9020300b05ba06.jpg', '5474c7479a54f3e99a9020300b05ba06'),
(22, 3, 'files/original/media_gallery/a7490c638137f93f2bafcedec84f8979.jpg', 'a7490c638137f93f2bafcedec84f8979'),
(23, 3, 'files/original/media_gallery/ba71f9b0bbcd3b63a4feb343616ea019.jpg', 'ba71f9b0bbcd3b63a4feb343616ea019');

-- --------------------------------------------------------

--
-- Структура таблицы `media_translate`
--

CREATE TABLE `media_translate` (
  `id` int(11) NOT NULL,
  `foreign_id` int(11) NOT NULL,
  `lang` varchar(255) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `media_translate`
--

INSERT INTO `media_translate` (`id`, `foreign_id`, `lang`, `key`, `value`) VALUES
(1, 1, 'ru', 'title', 'Fotogalereya01'),
(2, 1, 'ru', 'text', ''),
(3, 2, 'ru', 'title', 'Videogalereya01'),
(4, 2, 'ru', 'text', ''),
(5, 3, 'ru', 'title', 'Фото альбом №1'),
(6, 3, 'ru', 'text', ''),
(7, 1, 'oz', 'title', 'Видеогалерея'),
(8, 1, 'oz', 'text', ''),
(9, 2, 'oz', 'title', 'Фотогалерея'),
(10, 2, 'oz', 'text', ''),
(11, 3, 'oz', 'title', 'фото альбом №1'),
(12, 3, 'oz', 'text', '');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `media_category`
--
ALTER TABLE `media_category`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `media_category_translate`
--
ALTER TABLE `media_category_translate`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `media_gallery`
--
ALTER TABLE `media_gallery`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `media_translate`
--
ALTER TABLE `media_translate`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `media`
--
ALTER TABLE `media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `media_category`
--
ALTER TABLE `media_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `media_category_translate`
--
ALTER TABLE `media_category_translate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT для таблицы `media_gallery`
--
ALTER TABLE `media_gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT для таблицы `media_translate`
--
ALTER TABLE `media_translate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
