<?php

namespace Media\Model\Translate;

use Application\Mvc\Model\Translate;

class CategoryTranslate extends Translate
{

    public function getSource()
    {
        return "media_category_translate";
    }

} 